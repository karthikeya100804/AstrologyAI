import sqlite3
import json
import threading
from datetime import datetime


class SQLiteMemory:
    def __init__(self, db_path="astrology.db"):
        self.db_path = db_path
        self.lock = threading.Lock()
        self.init_db()

    def _connect(self):
        return sqlite3.connect(self.db_path)

    def init_db(self):
        conn = self._connect()
        cursor = conn.cursor()

        cursor.execute("""
        CREATE TABLE IF NOT EXISTS user_profiles (
            phone_number TEXT PRIMARY KEY,
            name TEXT,
            dob TEXT,
            birth_time TEXT,
            birth_place TEXT,
            birth_lat REAL,
            birth_lng REAL,
            chart_json TEXT,
            created_at TIMESTAMP
        )
        """)

        cursor.execute("""
        CREATE TABLE IF NOT EXISTS sessions (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            phone_number TEXT,
            role TEXT,
            content TEXT,
            timestamp TIMESTAMP
        )
        """)

        cursor.execute("""
        CREATE TABLE IF NOT EXISTS query_cache (
            cache_key TEXT PRIMARY KEY,
            result_json TEXT,
            created_at TIMESTAMP
        )
        """)

        conn.commit()
        conn.close()

    def get_profile(self, phone_number):
        conn = self._connect()
        cursor = conn.cursor()

        cursor.execute(
            "SELECT * FROM user_profiles WHERE phone_number = ?",
            (phone_number,)
        )

        row = cursor.fetchone()
        conn.close()

        if not row:
            return None

        columns = [
            "phone_number", "name", "dob", "birth_time",
            "birth_place", "birth_lat", "birth_lng",
            "chart_json", "created_at"
        ]

        profile = dict(zip(columns, row))

        if profile["chart_json"]:
            profile["chart_json"] = json.loads(profile["chart_json"])

        return profile

    def save_profile(self, phone_number, profile_dict):
        with self.lock:
            conn = self._connect()
            cursor = conn.cursor()

            chart_json = profile_dict.get("chart_json")
            if chart_json:
                chart_json = json.dumps(chart_json)

            cursor.execute("""
            INSERT OR REPLACE INTO user_profiles (
                phone_number, name, dob, birth_time,
                birth_place, birth_lat, birth_lng,
                chart_json, created_at
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
            """, (
                phone_number,
                profile_dict.get("name"),
                profile_dict.get("dob"),
                profile_dict.get("birth_time"),
                profile_dict.get("birth_place"),
                profile_dict.get("birth_lat"),
                profile_dict.get("birth_lng"),
                chart_json,
                datetime.utcnow()
            ))

            conn.commit()
            conn.close()

    def get_recent_messages(self, phone_number, n=12):
        conn = self._connect()
        cursor = conn.cursor()

        cursor.execute("""
        SELECT role, content FROM sessions
        WHERE phone_number = ?
        ORDER BY timestamp DESC
        LIMIT ?
        """, (phone_number, n))

        rows = cursor.fetchall()
        conn.close()

        messages = [{"role": r[0], "content": r[1]} for r in rows]

        return list(reversed(messages))

    def save_message_pair(self, phone_number, user_text, assistant_text):
        with self.lock:
            conn = self._connect()
            cursor = conn.cursor()

            now = datetime.utcnow()

            cursor.execute("""
            INSERT INTO sessions (phone_number, role, content, timestamp)
            VALUES (?, ?, ?, ?)
            """, (phone_number, "user", user_text, now))

            cursor.execute("""
            INSERT INTO sessions (phone_number, role, content, timestamp)
            VALUES (?, ?, ?, ?)
            """, (phone_number, "assistant", assistant_text, now))

            conn.commit()
            conn.close()