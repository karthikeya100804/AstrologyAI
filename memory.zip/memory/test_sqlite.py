from memory.sqlite import SQLiteMemory

db = SQLiteMemory()

# Test save profile
db.save_profile("123", {
    "name": "Test User",
    "dob": "01-01-2000",
    "birth_time": "10:30",
    "birth_place": "Hyderabad",
    "birth_lat": 17.3850,
    "birth_lng": 78.4867,
    "chart_json": {"test": "data"}
})

# Test get profile
profile = db.get_profile("123")
print(profile)

# Test messages
db.save_message_pair("123", "hello", "hi there")
msgs = db.get_recent_messages("123")
print(msgs)