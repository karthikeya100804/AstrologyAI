from chart.swisseph_wrapper import SwissEphChart
from agent.interpreter import AstrologyInterpreter

chart_engine = SwissEphChart()
interpreter = AstrologyInterpreter()


class Handlers:
    @staticmethod
    def handle_dob(profile, validated_dob):
        profile["dob"] = validated_dob
        profile["birth_time"] = None
        profile["birth_place"] = None
        profile["chart_json"] = None
        profile["menu_sent"] = False
        return profile, "What time were you born?\nPlease enter in HH:MM format.\nExample: 20:28"

    @staticmethod
    def handle_time(profile, validated_time):
        profile["birth_time"] = validated_time
        profile["birth_place"] = None
        profile["chart_json"] = None
        profile["menu_sent"] = False
        return profile, "Which city were you born in?\nExample: Nellore"

    @staticmethod
    def handle_city(profile, validated_city):
        profile["birth_place"] = validated_city
        profile["chart_json"] = None
        profile["menu_sent"] = False

        try:
            chart = chart_engine.compute_chart(
                profile["dob"],
                profile["birth_time"],
                validated_city,
                "",
                "India"
            )

            profile["chart_json"] = chart
            profile["menu_sent"] = True

            return profile, (
                "Chart calculated successfully.\n\n"
                "Choose a topic:\n"
                "1. Career\n"
                "2. Relationship\n"
                "3. Health\n"
                "4. Life Overview"
            )

        except Exception as e:
            print("Chart error:", e)
            profile["birth_place"] = None
            profile["chart_json"] = None
            return profile, "Could not find that birth city. Please enter only city name.\nExample: Nellore"

    @staticmethod
    def handle_topic(profile, message):
        chart = profile.get("chart_json")
        if not chart:
            return profile, "Chart not found. Please enter your birth city again."

        msg = message.strip().lower()

        if msg == "1" or "career" in msg:
            answer = interpreter.interpret(chart, "career")
            return profile, answer + "\n\nChoose another topic: 1 Career, 2 Relationship, 3 Health, 4 Life Overview"

        if msg == "2" or "relationship" in msg or "love" in msg:
            answer = interpreter.interpret(chart, "relationship")
            return profile, answer + "\n\nChoose another topic: 1 Career, 2 Relationship, 3 Health, 4 Life Overview"

        if msg == "3" or "health" in msg:
            answer = interpreter.interpret(chart, "health")
            return profile, answer + "\n\nChoose another topic: 1 Career, 2 Relationship, 3 Health, 4 Life Overview"

        if msg == "4" or "overview" in msg or "life" in msg:
            answer = interpreter.interpret(chart)
            return profile, answer + "\n\nChoose another topic: 1 Career, 2 Relationship, 3 Health, 4 Life Overview"

        return profile, "Please choose one option:\n1. Career\n2. Relationship\n3. Health\n4. Life Overview"

    @staticmethod
    def handle_question(profile, message):
        chart = profile.get("chart_json")
        if not chart:
            return "Chart not found. Please start again."

        msg = message.strip().lower()

        if msg == "1" or "career" in msg:
            return interpreter.interpret(chart, "career") + "\n\nChoose another topic: 1 Career, 2 Relationship, 3 Health, 4 Life Overview"

        if msg == "2" or "relationship" in msg or "love" in msg:
            return interpreter.interpret(chart, "relationship") + "\n\nChoose another topic: 1 Career, 2 Relationship, 3 Health, 4 Life Overview"

        if msg == "3" or "health" in msg:
            return interpreter.interpret(chart, "health") + "\n\nChoose another topic: 1 Career, 2 Relationship, 3 Health, 4 Life Overview"

        if msg == "4" or "overview" in msg or "life" in msg:
            return interpreter.interpret(chart) + "\n\nChoose another topic: 1 Career, 2 Relationship, 3 Health, 4 Life Overview"

        return interpreter.interpret(chart, message) + "\n\nAsk another question or choose 1, 2, 3, or 4."