import re
from datetime import datetime


class InputValidator:
    @staticmethod
    def validate_dob(text):
        text = text.strip()
        match = re.fullmatch(r"(\d{1,2})[/-](\d{1,2})[/-](\d{4})", text)
        if not match:
            return None

        d, m, y = map(int, match.groups())

        try:
            dt = datetime(y, m, d)
            if 1900 <= y <= 2024:
                return dt.strftime("%d/%m/%Y")
        except:
            return None

        return None

    @staticmethod
    def validate_time(text):
        text = text.strip()
        match = re.fullmatch(r"(\d{1,2}):(\d{2})", text)
        if not match:
            return None

        h, m = map(int, match.groups())

        if 0 <= h <= 23 and 0 <= m <= 59:
            return f"{h:02d}:{m:02d}"

        return None

    @staticmethod
    def validate_city(text):
        text = text.strip()
        text = re.sub(r"[^a-zA-Z\s]", "", text)
        text = re.sub(r"\s+", " ", text)

        if len(text) < 2:
            return None

        return text