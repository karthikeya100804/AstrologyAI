class StateManager:
    @staticmethod
    def get_current_state(profile):
        if not profile.get("dob"):
            return "AWAITING_DOB"

        if not profile.get("birth_time"):
            return "AWAITING_TIME"

        if not profile.get("birth_place"):
            return "AWAITING_CITY"

        if not profile.get("chart_json"):
            return "AWAITING_CITY"

        if not profile.get("menu_sent"):
            return "TOPIC_SELECTION"

        return "ANSWERING"