from fastapi import FastAPI, Request
from fastapi.responses import Response
from twilio.twiml.messaging_response import MessagingResponse
from dotenv import load_dotenv

from memory.sqlite import SQLiteMemory
from webhook.parser import InputValidator
from webhook.state_manager import StateManager
from webhook.handlers import Handlers

load_dotenv()

app = FastAPI()
memory = SQLiteMemory()


@app.post("/webhook")
async def receive_message(request: Request):
    form_data = await request.form()

    user_phone = form_data.get("From")
    user_text = (form_data.get("Body") or "").strip()

    twilio_response = MessagingResponse()

    if not user_phone:
        return Response(str(twilio_response), media_type="application/xml")

    if not user_text:
        twilio_response.message("Please send a message.")
        return Response(str(twilio_response), media_type="application/xml")

    try:
        profile = memory.get_profile(user_phone)

        if not profile:
            profile = {
                "phone_number": user_phone,
                "dob": None,
                "birth_time": None,
                "birth_place": None,
                "chart_json": None,
                "menu_sent": False
            }
            memory.save_profile(user_phone, profile)

        response = ""

        current_state = StateManager.get_current_state(profile)

        if current_state == "AWAITING_DOB":
            if user_text.lower() in ["hi", "hello", "hey", "start"]:
                response = "Welcome to Astrology AI.\nPlease enter your date of birth in DD/MM/YYYY format."
            else:
                validated_dob = InputValidator.validate_dob(user_text)
                if validated_dob:
                    profile, response = Handlers.handle_dob(profile, validated_dob)
                    memory.save_profile(user_phone, profile)
                else:
                    response = "Please enter a valid date of birth in DD/MM/YYYY format.\nExample: 10/08/2004"

        elif current_state == "AWAITING_TIME":
            validated_time = InputValidator.validate_time(user_text)
            if validated_time:
                profile, response = Handlers.handle_time(profile, validated_time)
                memory.save_profile(user_phone, profile)
            else:
                response = "Please enter a valid birth time in HH:MM format.\nExample: 20:28"

        elif current_state == "AWAITING_CITY":
            validated_city = InputValidator.validate_city(user_text)
            if validated_city:
                profile, response = Handlers.handle_city(profile, validated_city)
                memory.save_profile(user_phone, profile)
            else:
                response = "Please enter a valid birth city.\nExample: Nellore"

        elif current_state == "TOPIC_SELECTION":
            profile, response = Handlers.handle_topic(profile, user_text)
            memory.save_profile(user_phone, profile)

        else:
            response = Handlers.handle_question(profile, user_text)

        memory.save_message_pair(user_phone, user_text, response)

        twilio_response.message(response)
        return Response(str(twilio_response), media_type="application/xml")

    except Exception as e:
        print("Error:", e)
        import traceback
        traceback.print_exc()

        twilio_response.message("Error occurred. Please try again.")
        return Response(str(twilio_response), media_type="application/xml")