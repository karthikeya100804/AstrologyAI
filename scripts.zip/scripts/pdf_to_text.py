import pdfplumber
import json
import re
from pathlib import Path

from pdf2image import convert_from_path
import pytesseract
from PIL import ImageFilter, ImageOps


# =========================================================
# TESSERACT
# =========================================================

pytesseract.pytesseract.tesseract_cmd = (
    r"C:\Program Files\Tesseract-OCR\tesseract.exe"
)


# =========================================================
# POPPLER
# =========================================================

POPPLER_PATH = (
    r"C:\Users\kommu\OneDrive\Desktop\Projects\AstroAI\Release-26.02.0-0\poppler-26.02.0\Library\bin"
)


# =========================================================
# CLEAN TEXT
# =========================================================

def clean_text(text):

    if not text:
        return ""

    # normalize spaces
    text = re.sub(r"\s+", " ", text)

    # remove page numbers
    text = re.sub(r"Page\s+\d+", "", text)

    # remove URLs
    text = re.sub(r"http\S+", "", text)

    # remove repeated punctuation noise
    text = re.sub(r"[•·]+", " ", text)

    return text.strip()


# =========================================================
# OCR IMAGE PREPROCESSING
# =========================================================

def preprocess_image(image):

    # grayscale
    image = image.convert("L")

    # improve contrast
    image = ImageOps.autocontrast(image)

    # sharpen
    image = image.filter(ImageFilter.SHARPEN)

    # binary threshold
    image = image.point(
        lambda x: 0 if x < 180 else 255,
        "1"
    )

    return image


# =========================================================
# DETECT BAD EXTRACTION
# =========================================================

def is_garbage_text(text):

    if not text:
        return True

    if len(text.strip()) < 50:
        return True

    # weird OCR chars
    weird_chars = len(
        re.findall(r"[€<>|{}~`]", text)
    )

    if weird_chars > 10:
        return True

    # too many tiny broken words
    tiny_words = re.findall(
        r"\b[a-zA-Z]{1,2}\b",
        text
    )

    if len(tiny_words) > 60:
        return True

    # common OCR corruption patterns
    bad_patterns = [
        "H undr",
        "bsnefic",
        "cxceptionally",
        "astrologcrs",
        "tt ",
        "tl "
    ]

    hits = sum(
        1 for p in bad_patterns if p in text
    )

    if hits >= 2:
        return True

    return False


# =========================================================
# OCR FALLBACK
# =========================================================

def extract_text_with_ocr(pdf_path, page_num):

    try:

        images = convert_from_path(
            pdf_path,
            first_page=page_num + 1,
            last_page=page_num + 1,
            poppler_path=POPPLER_PATH,
            dpi=300
        )

        if not images:
            return ""

        image = images[0]

        # preprocess
        image = preprocess_image(image)

        # better OCR config
        custom_config = r"--oem 3 --psm 6"

        text = pytesseract.image_to_string(
            image,
            lang="eng+hin",
            config=custom_config
        )

        return text

    except Exception as e:

        print(
            f"OCR failed on page "
            f"{page_num + 1}: {e}"
        )

        return ""


# =========================================================
# SENTENCE-AWARE CHUNKING (NO NLTK)
# =========================================================

def semantic_chunk(text, max_chars=1800):

    # split by sentence endings
    sentences = re.split(
        r'(?<=[.!?।])\s+',
        text
    )

    chunks = []
    current = ""

    for sent in sentences:

        if not sent.strip():
            continue

        if len(current) + len(sent) < max_chars:
            current += " " + sent
        else:
            if current.strip():
                chunks.append(current.strip())
            current = sent

    if current.strip():
        chunks.append(current.strip())

    return chunks


# =========================================================
# MAIN PIPELINE
# =========================================================

def extract_text_from_pdfs():

    raw_dir = Path("data/raw")

    if not raw_dir.exists():
        print(f"Folder not found: {raw_dir}")
        return

    pdf_files = list(raw_dir.glob("*.pdf"))

    if not pdf_files:
        print(f"No PDFs found in {raw_dir}")
        return

    print(f"Found {len(pdf_files)} PDFs\n")

    chunks_list = []
    chunk_id = 0

    for pdf_path in pdf_files:

        print(f"Processing: {pdf_path.name}")

        try:

            with pdfplumber.open(pdf_path) as pdf:

                total_pages = len(pdf.pages)
                print(f"Total pages: {total_pages}")

                file_chunk_count = 0

                for page_num, page in enumerate(pdf.pages):

                    # =====================================
                    # NORMAL EXTRACTION
                    # =====================================

                    text = page.extract_text()

                    # =====================================
                    # OCR FALLBACK
                    # =====================================

                    if (
                        not text
                        or len(text.strip()) < 50
                        or is_garbage_text(text)
                    ):

                        print(
                            f"Using OCR on page "
                            f"{page_num + 1}"
                        )

                        text = extract_text_with_ocr(
                            pdf_path,
                            page_num
                        )

                    if not text:
                        continue

                    # clean
                    text = clean_text(text)

                    if len(text) < 100:
                        continue

                    # final garbage check
                    if is_garbage_text(text):
                        continue

                    # =====================================
                    # SEMANTIC CHUNKING
                    # =====================================

                    chunks = semantic_chunk(text)

                    for chunk_text in chunks:

                        if len(chunk_text) < 100:
                            continue

                        chunks_list.append({

                            "chunk_id":
                            f"chunk_{chunk_id}",

                            "source_file":
                            pdf_path.name,

                            "page":
                            page_num + 1,

                            "text":
                            chunk_text,

                            "language":
                            "bilingual"
                        })

                        chunk_id += 1
                        file_chunk_count += 1

                print(
                    f"Extracted "
                    f"{file_chunk_count} chunks\n"
                )

        except Exception as e:

            print(
                f"ERROR processing "
                f"{pdf_path.name}: {e}\n"
            )

    # =====================================================
    # SAVE
    # =====================================================

    output_path = Path("data/chunks.json")

    output_path.parent.mkdir(
        parents=True,
        exist_ok=True
    )

    with open(
        output_path,
        "w",
        encoding="utf-8"
    ) as f:

        json.dump(
            chunks_list,
            f,
            indent=2,
            ensure_ascii=False
        )

    print("\n=================================")
    print(f"Total chunks: {len(chunks_list)}")
    print(f"Saved to: {output_path}")

    size_mb = (
        output_path.stat().st_size
        / (1024 * 1024)
    )

    print(f"Output size: {size_mb:.2f} MB")
    print("=================================")


# =========================================================
# RUN
# =========================================================

if __name__ == "__main__":
    extract_text_from_pdfs()