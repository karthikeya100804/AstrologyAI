'''import json
import os
import time
from pathlib import Path
from dotenv import load_dotenv
import google.generativeai as genai

load_dotenv()

API_KEY = os.getenv("GEMINI_API_KEY")
if not API_KEY:
    raise ValueError("GEMINI_API_KEY not set in .env")

genai.configure(api_key=API_KEY)
model = genai.GenerativeModel("gemini-2.5-flash")

EXTRACTION_PROMPT = """Extract entities and relationships from this astrology text.
The text may be in Hindi, English, or both.

Return ONLY valid JSON array. No markdown, no explanations.

Each object must have:
- source_name (string, in English transliteration if Hindi)
- source_type (string: "Planet", "Sign", "House", "Concept", "Yoga", "Nakshatra", "Dasha")
- relationship (string: "rules", "governs", "exalted_in", "debilitated_in", "aspects", "signifies", "associated_with")
- target_name (string, in English transliteration if Hindi)
- target_type (string: same options)
- context (string: 1 sentence summary in English)

If the text is in Hindi, transliterate entity names to English.

Example:
[
  {{"source_name": "Mars", "source_type": "Planet", "relationship": "rules", "target_name": "Aries", "target_type": "Sign", "context": "Mars naturally rules Aries"}},
  {{"source_name": "Shani", "source_type": "Planet", "relationship": "aspects", "target_name": "10th house", "target_type": "House", "context": "Saturn aspects the 3rd 7th and 10th houses"}}
]

If no entities found, return: []

TEXT:
{text}

JSON ARRAY:"""

def extract_entities():
    """Extract entities from bilingual PDF chunks"""
    
    chunks_path = Path("data/chunks.json")
    
    if not chunks_path.exists():
        print("Run pdf_to_text.py first")
        return
    
    with open(chunks_path, encoding='utf-8') as f:
        chunks = json.load(f)
    
    print(f"Extracting entities from {len(chunks)} chunks...\n")
    
    triples = []
    failed_chunks = []
    
    for idx, chunk in enumerate(chunks):
        if idx % 10 == 0:
            print(f"Progress: {idx}/{len(chunks)}")
            if idx > 0:
                time.sleep(5)  # Rate limit: 5 sec every 10 chunks
        
        chunk_text = chunk["text"][:2500]  # Increased for bilingual text
        
        prompt = EXTRACTION_PROMPT.format(text=chunk_text)
        
        try:
            response = model.generate_content(prompt, safety_settings=[])
            response_text = response.text.strip()
            
            # Try to parse JSON
            try:
                extracted = json.loads(response_text)
                
                if isinstance(extracted, list):
                    for item in extracted:
                        if all(k in item for k in ["source_name", "relationship", "target_name"]):
                            item["chunk_id"] = chunk["chunk_id"]
                            item["source_file"] = chunk["source_file"]
                            item["language"] = "bilingual"
                            triples.append(item)
            
            except json.JSONDecodeError as e:
                print(f"JSON parse error on chunk {idx}: {e}")
                failed_chunks.append(idx)
        
        except Exception as e:
            print(f"API error on chunk {idx}: {e}")
            failed_chunks.append(idx)
    
    # Save triples
    output_path = Path("data/triples.json")
    with open(output_path, "w", encoding='utf-8') as f:
        json.dump(triples, f, indent=2, ensure_ascii=False)
    
    print(f"Extracted {len(triples)} triples")
    print(f"Failed chunks: {len(failed_chunks)}")
    print(f"Saved to {output_path}")

if __name__ == "__main__":
    extract_entities()
    '''

import json
import time
import re
from pathlib import Path
from dotenv import load_dotenv
import os

import google.generativeai as genai


# =====================================================
# ENV
# =====================================================

load_dotenv()

API_KEY = os.getenv("GEMINI_API_KEY")
if not API_KEY:
    raise ValueError("GEMINI_API_KEY not set in .env")

genai.configure(api_key=API_KEY)

model = genai.GenerativeModel("gemini-2.5-flash")


# =====================================================
# CONFIG
# =====================================================

BATCH_SIZE = 5
MAX_RETRIES = 3


# =====================================================
# PROMPT
# =====================================================

EXTRACTION_PROMPT = """
You are extracting astrology knowledge graph relationships.

TASK:
Extract ONLY meaningful nuanced astrology relationships.

DO NOT extract obvious canonical astrology facts such as:
- Mars rules Aries
- Venus rules Taurus
- Saturn aspects 3rd/7th/10th
- fixed zodiac ownership

ONLY extract:
- yogas
- conditions
- combinations
- nuanced interpretations
- conditional house/planet relationships
- predictive rules
- special combinations

Return ONLY valid JSON array.

Format:
[
  {
    "source_name": "...",
    "source_type": "Planet|Sign|House|Concept|Yoga|Nakshatra|Dasha",
    "relationship": "...",
    "target_name": "...",
    "target_type": "Planet|Sign|House|Concept|Yoga|Nakshatra|Dasha",
    "context": "1 sentence English summary"
  }
]

If nothing useful exists:
[]

TEXT:
{text}
"""


# =====================================================
# HELPERS
# =====================================================

def normalize_entity(name):

    if not name:
        return ""

    name = name.strip()
    name = re.sub(r"\s+", " ", name)

    mapping = {
        "mangala": "Mars",
        "kuja": "Mars",
        "shani": "Saturn",
        "guru": "Jupiter",
        "budha": "Mercury",
        "shukra": "Venus",
        "chandra": "Moon",
        "surya": "Sun",
        "rahu": "Rahu",
        "ketu": "Ketu"
    }

    lower = name.lower()

    if lower in mapping:
        return mapping[lower]

    return name


def is_valid_triple(item):

    required = [
        "source_name",
        "source_type",
        "relationship",
        "target_name",
        "target_type",
        "context"
    ]

    if not all(k in item for k in required):
        return False

    if not item["source_name"] or not item["target_name"]:
        return False

    if item["source_name"].lower() in ["it", "this", "that"]:
        return False

    if item["target_name"].lower() in ["it", "this", "that"]:
        return False

    if len(item["context"]) < 10:
        return False

    return True


def dedup_key(item):

    return (
        item["source_name"].lower(),
        item["relationship"].lower(),
        item["target_name"].lower()
    )


# =====================================================
# GEMINI CALL
# =====================================================

def extract_batch(batch_text):

    prompt = EXTRACTION_PROMPT.replace(
    "{text}",
    batch_text
    )

    for attempt in range(MAX_RETRIES):

        try:

            response = model.generate_content(
                prompt,
                generation_config={
                    "temperature": 0.2,
                    "response_mime_type": "application/json"
                }
            )

            text = response.text.strip()

            parsed = json.loads(text)

            if isinstance(parsed, list):
                return parsed

            return []

        except Exception as e:

            print(
                f"Retry {attempt + 1}/{MAX_RETRIES} failed: {e}"
            )

            time.sleep(3)

    return []


# =====================================================
# MAIN
# =====================================================

def extract_entities():

    chunks_path = Path("data/chunks.json")

    if not chunks_path.exists():
        print("Run pdf_to_text.py first")
        return

    with open(
        chunks_path,
        encoding="utf-8"
    ) as f:
        chunks = json.load(f)

    print(f"Loaded {len(chunks)} chunks")

    triples = []
    seen = set()

    total_batches = (
        len(chunks) + BATCH_SIZE - 1
    ) // BATCH_SIZE

    for batch_idx in range(total_batches):

        start = batch_idx * BATCH_SIZE
        end = start + BATCH_SIZE

        batch_chunks = chunks[start:end]

        print(
            f"Batch {batch_idx + 1}/{total_batches}"
        )

        batch_text = "\n\n".join(
            c["text"][:2000]
            for c in batch_chunks
        )

        extracted = extract_batch(batch_text)

        for item in extracted:

            if not is_valid_triple(item):
                continue

            item["source_name"] = normalize_entity(
                item["source_name"]
            )

            item["target_name"] = normalize_entity(
                item["target_name"]
            )

            key = dedup_key(item)

            if key in seen:
                continue

            seen.add(key)

            item["batch_id"] = batch_idx

            triples.append(item)

        time.sleep(2)

    # save
    output_path = Path("data/triples.json")

    with open(
        output_path,
        "w",
        encoding="utf-8"
    ) as f:

        json.dump(
            triples,
            f,
            indent=2,
            ensure_ascii=False
        )

    print("\n============================")
    print(f"Triples extracted: {len(triples)}")
    print(f"Saved to: {output_path}")
    print("============================")


# =====================================================
# RUN
# =====================================================

if __name__ == "__main__":
    extract_entities()