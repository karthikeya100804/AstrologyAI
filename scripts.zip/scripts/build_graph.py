'''import json
from pathlib import Path
import networkx as nx
from sentence_transformers import SentenceTransformer

def build_graph():
    """Build NetworkX graph from triples"""
    
    triples_path = Path("data/triples.json")
    chunks_path = Path("data/chunks.json")
    
    if not triples_path.exists():
        print("Run extract_entities.py first")
        return
    
    print("Loading data...")
    with open(triples_path) as f:
        triples = json.load(f)
    
    with open(chunks_path) as f:
        chunks = {c["chunk_id"]: c["text"] for c in json.load(f)}
    
    print(f"Building graph from {len(triples)} triples...")
    
    # Create graph
    G = nx.MultiDiGraph()
    
    # Load embeddings model (first run downloads it)
    print("Loading embeddings model...")
    embedder = SentenceTransformer("BAAI/bge-small-en-v1.5")
    
    # Add nodes
    added_nodes = set()
    
    for triple in triples:
        source = triple.get("source_name", "Unknown")
        target = triple.get("target_name", "Unknown")
        source_type = triple.get("source_type", "Concept")
        target_type = triple.get("target_type", "Concept")
        
        for name, node_type in [(source, source_type), (target, target_type)]:
            if name not in added_nodes:
                # Get context text
                chunk_id = triple.get("chunk_id")
                context_text = chunks.get(chunk_id, name)[:500]
                
                # Embed
                try:
                    embedding = embedder.encode(context_text, show_progress_bar=False).tolist()
                except:
                    embedding = [0] * 384  # fallback
                
                G.add_node(name, 
                          node_type=node_type, 
                          description=context_text,
                          embedding=embedding)
                added_nodes.add(name)
    
    # Add edges
    for triple in triples:
        source = triple.get("source_name", "Unknown")
        target = triple.get("target_name", "Unknown")
        relationship = triple.get("relationship", "associated_with")
        context = triple.get("context", "")
        
        if source in G.nodes and target in G.nodes:
            G.add_edge(source, target,
                      relationship=relationship,
                      context=context)
    
    print(f"Graph created: {len(G.nodes)} nodes, {len(G.edges)} edges")
    
    # Save graph
    output_path = Path("data/astrology_graph.json")
    output_path.parent.mkdir(parents=True, exist_ok=True)
    
    data = nx.node_link_data(G)
    
    with open(output_path, "w") as f:
        json.dump(data, f)
    
    print(f"Saved to {output_path}")
    print(f"File size: {output_path.stat().st_size / 1024 / 1024:.2f} MB")

if __name__ == "__main__":
    build_graph()'''

import json
import re
from pathlib import Path
import networkx as nx
from sentence_transformers import SentenceTransformer


class AstrologyGraphBuilder:

    def __init__(self):
        self.embedder = SentenceTransformer("BAAI/bge-small-en-v1.5")

    # ==========================================
    # Normalize entity names
    # ==========================================
    def normalize_entity(self, name):

        if not name:
            return ""

        name = name.strip()
        name = re.sub(r"\s+", " ", name)

        mapping = {
            "mangala": "Mars",
            "kuja": "Mars",
            "shani": "Saturn",
            "guru": "Jupiter",
            "budha": "Mercury",
            "shukra": "Venus",
            "chandra": "Moon",
            "surya": "Sun"
        }

        lower = name.lower()

        if lower in mapping:
            return mapping[lower]

        return name

    # ==========================================
    # Semantic node text for embedding
    # ==========================================
    def build_node_text(self, node_name, node_type, triples):

        contexts = []

        for triple in triples:

            if (
                triple["source_name"] == node_name
                or triple["target_name"] == node_name
            ):
                context = triple.get("context", "")
                if context:
                    contexts.append(context)

        context_text = " ".join(contexts[:5])

        semantic_text = (
            f"{node_name}. "
            f"Type: {node_type}. "
            f"{context_text}"
        )

        return semantic_text[:1000]

    # ==========================================
    # Build graph
    # ==========================================
    def build_graph(self):

        triples_path = Path("data/triples.json")

        if not triples_path.exists():
            print("Run extract_entities.py first")
            return

        print("Loading triples...")

        with open(triples_path, encoding="utf-8") as f:
            triples = json.load(f)

        print(f"Loaded {len(triples)} triples")

        print("Creating graph...")

        G = nx.DiGraph()

        # ------------------------------
        # Collect unique nodes
        # ------------------------------
        node_info = {}

        for triple in triples:

            source = self.normalize_entity(
                triple.get("source_name", "")
            )

            target = self.normalize_entity(
                triple.get("target_name", "")
            )

            source_type = triple.get(
                "source_type",
                "Concept"
            )

            target_type = triple.get(
                "target_type",
                "Concept"
            )

            batch_id = triple.get("batch_id")

            if source and source not in node_info:
                node_info[source] = {
                    "node_type": source_type,
                    "chunk_refs": set()
                }

            if target and target not in node_info:
                node_info[target] = {
                    "node_type": target_type,
                    "chunk_refs": set()
                }

            if source:
                node_info[source]["chunk_refs"].add(batch_id)

            if target:
                node_info[target]["chunk_refs"].add(batch_id)

        print(f"Unique nodes: {len(node_info)}")

        # ------------------------------
        # Add nodes
        # ------------------------------
        print("Embedding nodes...")

        for node_name, info in node_info.items():

            node_type = info["node_type"]

            semantic_text = self.build_node_text(
                node_name,
                node_type,
                triples
            )

            try:
                embedding = self.embedder.encode(
                    semantic_text,
                    show_progress_bar=False
                ).tolist()

            except Exception as e:
                print(f"Embedding failed for {node_name}: {e}")
                embedding = []

            G.add_node(
                node_name,
                node_type=node_type,
                description=semantic_text,
                embedding=embedding,
                chunk_refs=list(info["chunk_refs"])
            )

        # ------------------------------
        # Add edges (deduplicated)
        # ------------------------------
        print("Adding edges...")

        seen_edges = set()

        for triple in triples:

            source = self.normalize_entity(
                triple.get("source_name", "")
            )

            target = self.normalize_entity(
                triple.get("target_name", "")
            )

            relationship = triple.get(
                "relationship",
                "associated_with"
            )

            context = triple.get(
                "context",
                ""
            )

            batch_id = triple.get("batch_id")

            edge_key = (
                source.lower(),
                relationship.lower(),
                target.lower()
            )

            if edge_key in seen_edges:
                continue

            seen_edges.add(edge_key)

            if source in G.nodes and target in G.nodes:

                G.add_edge(
                    source,
                    target,
                    relationship=relationship,
                    context=context,
                    chunk_ref=batch_id
                )

        print(
            f"Graph created: "
            f"{len(G.nodes)} nodes, "
            f"{len(G.edges)} edges"
        )

        # ------------------------------
        # Save
        # ------------------------------
        output_path = Path("data/astrology_graph.json")
        output_path.parent.mkdir(
            parents=True,
            exist_ok=True
        )

        graph_data = nx.node_link_data(G)

        with open(
            output_path,
            "w",
            encoding="utf-8"
        ) as f:
            json.dump(
                graph_data,
                f,
                indent=2,
                ensure_ascii=False
            )

        print(f"Saved to {output_path}")
        print(
            f"Size: "
            f"{output_path.stat().st_size / 1024 / 1024:.2f} MB"
        )


if __name__ == "__main__":

    builder = AstrologyGraphBuilder()
    builder.build_graph()