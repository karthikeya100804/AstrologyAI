import json
from pathlib import Path
import networkx as nx

class GraphLoader:
    def __init__(self):
        self.G = None
        self.load_graph()
    
    def load_graph(self):
        """Load the saved graph"""
        graph_path = Path("data/astrology_graph.json")
        
        if not graph_path.exists():
            raise FileNotFoundError(f"Graph not found at {graph_path}. Run build_graph.py first.")
        
        print("Loading graph...")
        with open(graph_path) as f:
            data = json.load(f)
        
        self.G = nx.node_link_graph(data, directed=True, multigraph=True)
        print(f"Graph loaded: {len(self.G.nodes)} nodes, {len(self.G.edges)} edges")
    
    def get_node_description(self, node_name):
        """Get description of a node"""
        if node_name in self.G.nodes:
            return self.G.nodes[node_name].get("description", "")
        return ""
    
    def get_connected_nodes(self, node_name, depth=2):
        """Get all nodes connected within N hops"""
        if node_name not in self.G.nodes:
            return []
        
        subgraph = nx.ego_graph(self.G, node_name, radius=depth, undirected=False)
        descriptions = []
        
        for node in subgraph.nodes:
            desc = subgraph.nodes[node].get("description", "")
            if desc:
                descriptions.append(desc)
        
        return descriptions
    
    def search_nodes(self, keyword):
        """Find nodes matching a keyword"""
        keyword_lower = keyword.lower()
        matching = [node for node in self.G.nodes 
                   if keyword_lower in node.lower()]
        return matching

# Global loader instance
loader = GraphLoader()