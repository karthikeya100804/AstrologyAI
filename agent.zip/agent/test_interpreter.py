from chart.swisseph_wrapper import SwissEphChart
from agent.interpreter import AstrologyInterpreter

# Create chart
engine = SwissEphChart()
chart = engine.compute_chart(
    dob_str="10/08/2004",
    time_str="20:28",
    city="Nellore",
    state="Andhra Pradesh",
    country="India"
)

# Interpret
interpreter = AstrologyInterpreter()

# Get general overview
print("=" * 60)
print("ASTROLOGY READING")
print("=" * 60)
overview = interpreter.interpret(chart)
print(overview)

# Answer specific questions
print("\n" + "=" * 60)
print("CAREER QUESTION")
print("=" * 60)
career = interpreter.interpret(chart, "What careers suit my chart?")
print(career)

print("\n" + "=" * 60)
print("LOVE QUESTION")
print("=" * 60)
love = interpreter.interpret(chart, "What is my relationship style?")
print(love)