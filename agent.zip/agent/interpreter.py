'''import os
from dotenv import load_dotenv
import google.generativeai as genai


class AstrologyInterpreter:
    def __init__(self):
        load_dotenv()

        api_key = os.getenv("GEMINI_API_KEY")
        if not api_key:
            raise ValueError("GEMINI_API_KEY not set")

        genai.configure(api_key=api_key)

        self.model = genai.GenerativeModel(
            "gemini-2.5-flash",
            generation_config={
                "temperature": 0.7,
                "max_output_tokens": 800
            }
        )

    def interpret(self, chart, user_question=None):
        """Generate reading based on chart and optional question"""
        
        chart_summary = self._build_chart_summary(chart)
        
        if user_question:
            prompt = self._build_question_prompt(chart, chart_summary, user_question)
        else:
            prompt = self._build_overview_prompt(chart, chart_summary)

        response = self.model.generate_content(prompt)
        return response.text.strip()

    def _build_overview_prompt(self, chart, chart_summary):
        """Build prompt for general chart overview"""
        
        return f"""You are an expert Vedic astrologer.

Use ONLY the provided chart data. Do not invent facts.
Keep answers practical and specific. No generic statements.
Do NOT explain your reasoning.

CHART DATA
{chart_summary}

TASK
Provide a brief personality and life overview based on this chart.

Structure your response as:

Personality:
[2-3 sentences on personality based on Lagna, Moon, Nakshatra]

Current Life Phase:
[2-3 sentences on what the current dasha/antardasha brings]

Key Strengths:
[2-3 key abilities and talents]

Areas to Work On:
[2-3 challenges or growth areas]

Overview:"""
        
    def _build_question_prompt(self, chart, chart_summary, question):
        """Build prompt for answering a specific question"""
        
        return f"""You are an expert Vedic astrologer.

Use ONLY the provided chart data. Do not invent facts.
If the chart data does not support an answer, say: I do not have enough information on this specific combination.
Keep answers practical and specific.
Do NOT explain your reasoning.

CHART DATA
{chart_summary}

USER QUESTION
{question}

TASK
Answer the question using ONLY the chart data provided above.
Keep response to 4-5 sentences maximum.

Answer:"""

    def _build_chart_summary(self, chart):
        """Build a complete chart data string"""
        
        planets_str = "\n".join([
            f"  {name}: {data['sign']} {data['degree']:.1f}°"
            for name, data in chart["planets"].items()
        ])
        
        return f"""Lagna: {chart["lagna"]["sign"]} {chart["lagna"]["degree"]:.1f}°
Moon Sign: {chart["planets"]["Moon"]["sign"]}
Moon Nakshatra: {chart["moon_nakshatra"]}
Mahadasha: {chart["current_dasha"]}
Antardasha: {chart["active_antardasha"]["antardasha"]}

Planet Positions:
{planets_str}"""

    def _get_lagna_lord(self, chart):
        """Get the ruler of the lagna sign"""
        sign_rulers = {
            "Aries": "Mars", "Taurus": "Venus", "Gemini": "Mercury",
            "Cancer": "Moon", "Leo": "Sun", "Virgo": "Mercury",
            "Libra": "Venus", "Scorpio": "Mars", "Sagittarius": "Jupiter",
            "Capricorn": "Saturn", "Aquarius": "Saturn", "Pisces": "Jupiter"
        }
        lagna_sign = chart["lagna"]["sign"]
        return sign_rulers.get(lagna_sign, "Unknown")

'''
class AstrologyInterpreter:
    def __init__(self):
        pass

    def interpret(self, chart, user_question=None):
        """Generate hardcoded reading for testing"""
        
        lagna = chart.get("lagna", {}).get("sign", "Unknown")
        moon_sign = chart.get("planets", {}).get("Moon", {}).get("sign", "Unknown")
        dasha = chart.get("current_dasha", "Unknown")
        
        if user_question:
            return self._answer_question(lagna, moon_sign, dasha, user_question)
        else:
            return self._overview(lagna, moon_sign, dasha)
    
    def _overview(self, lagna, moon_sign, dasha):
        """Hardcoded overview"""
        return f"""Personality:
You have a {lagna} Lagna with {moon_sign} Moon. This makes you practical, thoughtful, and emotionally stable.

Current Life Phase:
You are currently in {dasha} Mahadasha. This period brings focus on growth, learning, and personal development.

Key Strengths:
- Strong analytical mind
- Ability to adapt to changes
- Good communicator

Areas to Work On:
- Overthinking situations
- Need for more physical activity
- Balance work and personal life"""
    
    def _answer_question(self, lagna, moon_sign, dasha, question):
        """Hardcoded answers based on question type"""
        
        q = question.lower()
        
        if "career" in q:
            return f"""Based on your {lagna} Lagna and {dasha} Mahadasha:

Your chart shows strong potential in analytical and communication fields. Consider careers in education, writing, consulting, or management.

The current {dasha} period favors structured work environments. This is a good time for career advancement and professional growth.

Focus on developing leadership skills during this phase."""
        
        elif "relationship" in q or "love" in q:
            return f"""Your {moon_sign} Moon indicates emotional depth and loyalty in relationships.

With {lagna} Lagna, you seek stability and commitment. You are a caring and devoted partner.

The current {dasha} period can bring new connections or strengthen existing relationships. Focus on open communication.

Green flags for you: Honesty, intellectual compatibility, emotional support."""
        
        elif "health" in q:
            return f"""Your {lagna} Lagna suggests a naturally balanced constitution.

Pay attention to digestion and stress management. Regular exercise and meditation help maintain wellness.

The current {dasha} period is favorable for health improvements. This is a good time to start new wellness routines.

Avoid overwork and get adequate sleep."""
        
        else:
            return f"""Based on your {lagna} Lagna with {moon_sign} Moon sign, currently in {dasha} Mahadasha:

You are entering a phase of growth and opportunity. The stars favor your efforts in multiple areas of life.

Focus on: Personal development, health, relationships, and career growth.

This is an auspicious time to pursue your goals with confidence."""