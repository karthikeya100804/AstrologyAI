import swisseph as swe
from datetime import datetime
from geopy.geocoders import Nominatim
from timezonefinder import TimezoneFinder
import pytz


class SwissEphChart:
    def __init__(self):
        self.geolocator = Nominatim(user_agent="astroai")
        self.tf = TimezoneFinder()

        # Lahiri ayanamsa (Vedic)
        swe.set_sid_mode(swe.SIDM_LAHIRI)

    def compute_chart(self, dob_str, time_str, city, state, country):
        # ---- parse ----
        day, month, year = self._parse_dob(dob_str)
        hour, minute = self._parse_time(time_str)

        birth_date = datetime(year, month, day)


        # ---- geocode ----
        location = self.geolocator.geocode(f"{city}, {state}, {country}")
        if not location:
            raise ValueError("Invalid location")

        lat = location.latitude
        lng = location.longitude

        # ---- timezone ----
        tz_name = self.tf.timezone_at(lat=lat, lng=lng)
        if not tz_name:
            raise ValueError("Timezone not found")

        tz = pytz.timezone(tz_name)

        local_dt = tz.localize(datetime(year, month, day, hour, minute))
        utc_dt = local_dt.astimezone(pytz.utc)

        # ---- Julian Day ----
        jd = swe.julday(
            utc_dt.year,
            utc_dt.month,
            utc_dt.day,
            utc_dt.hour + utc_dt.minute / 60.0
        )

        # ---- Ayanamsa (critical fix) ----
        ayanamsa = swe.get_ayanamsa(jd)

        # ---- planets ----
        planet_map = {
            "Sun": swe.SUN,
            "Moon": swe.MOON,
            "Mars": swe.MARS,
            "Mercury": swe.MERCURY,
            "Jupiter": swe.JUPITER,
            "Venus": swe.VENUS,
            "Saturn": swe.SATURN,
            "Rahu": swe.MEAN_NODE
        }

        chart = {
            "lagna": None,
            "planets": {},
            "coordinates": {"lat": lat, "lng": lng}
        }

        for name, pid in planet_map.items():
            tropical_lon = swe.calc_ut(jd, pid)[0][0]

            # ---- sidereal correction ----
            lon = (tropical_lon - ayanamsa) % 360

            chart["planets"][name] = {
                "longitude": lon,
                "sign": self._get_sign(lon),
                "degree": lon % 30
            }

        # ---- Ketu ----
        rahu_lon = chart["planets"]["Rahu"]["longitude"]
        ketu_lon = (rahu_lon + 180) % 360

        chart["planets"]["Ketu"] = {
            "longitude": ketu_lon,
            "sign": self._get_sign(ketu_lon),
            "degree": ketu_lon % 30
        }

        # ---- Lagna (ascendant) ----
        houses = swe.houses(jd, lat, lng)
        tropical_asc = houses[0][0]

        asc = (tropical_asc - ayanamsa) % 360

        chart["lagna"] = {
            "longitude": asc,
            "sign": self._get_sign(asc),
            "degree": asc % 30
        }

        moon_lon = chart["planets"]["Moon"]["longitude"]
        chart["moon_nakshatra"] = self.get_nakshatra(moon_lon)
        chart["moon_pada"] = self.get_nakshatra_pada(moon_lon)
        chart["dasha"] = self.compute_vimshottari_dasha(moon_lon)
        chart["current_dasha"] = self.compute_current_dasha(moon_lon=chart["planets"]["Moon"]["longitude"],birth_date=birth_date)
        chart["antardasha"] = self.compute_antardasha(chart["current_dasha"])
        chart["active_antardasha"] = self.compute_active_antardasha(moon_lon=moon_lon,birth_date=birth_date)

        return chart

    # -------- helpers -------- #

    def _parse_dob(self, dob):
        d, m, y = dob.replace("-", "/").split("/")
        return int(d), int(m), int(y)

    def _parse_time(self, t):
        h, m = t.split(":")
        return int(h), int(m)

    def _get_sign(self, lon):
        signs = [
            "Aries", "Taurus", "Gemini", "Cancer",
            "Leo", "Virgo", "Libra", "Scorpio",
            "Sagittarius", "Capricorn", "Aquarius", "Pisces"
        ]
        return signs[int(lon // 30)]
    
    def get_nakshatra(self, longitude):
        nakshatras = [
            "Ashwini", "Bharani", "Krittika", "Rohini", "Mrigashira",
            "Ardra", "Punarvasu", "Pushya", "Ashlesha", "Magha",
            "Purva Phalguni", "Uttara Phalguni", "Hasta", "Chitra",
            "Swati", "Vishakha", "Anuradha", "Jyeshtha", "Mula",
            "Purva Ashadha", "Uttara Ashadha", "Shravana", "Dhanishta",
            "Shatabhisha", "Purva Bhadrapada", "Uttara Bhadrapada", "Revati"
        ]

        nakshatra_size = 360 / 27  # 13.3333°

        index = int(longitude // nakshatra_size)

        return nakshatras[index]
    
    def get_nakshatra_pada(self, longitude):
        size = 360 / 27
        pada_size = size / 4
        return int((longitude % size) // pada_size) + 1
    
    def compute_vimshottari_dasha(self, moon_lon):
        nakshatra_size = 360 / 27

        # nakshatra index
        nak_index = int(moon_lon // nakshatra_size)

        # dasha sequence
        dasha_sequence = [
            "Ketu", "Venus", "Sun", "Moon", "Mars",
            "Rahu", "Jupiter", "Saturn", "Mercury"
        ]

        dasha_years = {
            "Ketu": 7, "Venus": 20, "Sun": 6, "Moon": 10,
            "Mars": 7, "Rahu": 18, "Jupiter": 16,
            "Saturn": 19, "Mercury": 17
        }

        # starting dasha lord
        dasha_lord = dasha_sequence[nak_index % 9]

        # degree inside nakshatra
        position_in_nak = moon_lon % nakshatra_size

        # balance calculation
        balance = 1 - (position_in_nak / nakshatra_size)

        remaining_years = dasha_years[dasha_lord] * balance

        return {
            "current_dasha": dasha_lord,
            "remaining_years": remaining_years
        }
    
    def compute_current_dasha(self, moon_lon, birth_date):
        nakshatra_size = 360 / 27

        dasha_sequence = [
            "Ketu", "Venus", "Sun", "Moon", "Mars",
            "Rahu", "Jupiter", "Saturn", "Mercury"
        ]

        dasha_years = {
            "Ketu": 7, "Venus": 20, "Sun": 6, "Moon": 10,
            "Mars": 7, "Rahu": 18, "Jupiter": 16,
            "Saturn": 19, "Mercury": 17
        }

        # ---- Step 1: find starting dasha ----
        nak_index = int(moon_lon // nakshatra_size)
        start_dasha = dasha_sequence[nak_index % 9]

        # ---- Step 2: balance at birth ----
        position_in_nak = moon_lon % nakshatra_size
        balance = 1 - (position_in_nak / nakshatra_size)

        remaining_years = dasha_years[start_dasha] * balance

        # ---- Step 3: years passed since birth ----
        today = datetime.utcnow()
        years_passed = (today - birth_date).days / 365.25

        # ---- Step 4: move through dasha cycle ----
        current_index = dasha_sequence.index(start_dasha)

        # first consume balance
        if years_passed < remaining_years:
            return start_dasha

        years_passed -= remaining_years
        current_index = (current_index + 1) % 9

        while True:
            dasha = dasha_sequence[current_index]
            duration = dasha_years[dasha]

            if years_passed < duration:
                return dasha

            years_passed -= duration
            current_index = (current_index + 1) % 9

    def compute_antardasha(self, current_dasha):
        seq = ["Ketu","Venus","Sun","Moon","Mars","Rahu","Jupiter","Saturn","Mercury"]

        years_map = {
            "Ketu":7,"Venus":20,"Sun":6,"Moon":10,
            "Mars":7,"Rahu":18,"Jupiter":16,
            "Saturn":19,"Mercury":17
        }

        total_cycle = 120  # total vimshottari

        antardasha_list = []

        for sub in seq:
            duration = (years_map[current_dasha] * years_map[sub]) / total_cycle
            antardasha_list.append({
                "antardasha": f"{current_dasha}/{sub}",
                "duration_years": duration
            })

        return antardasha_list
    
    def compute_active_antardasha(self, moon_lon, birth_date):
        seq = ["Ketu","Venus","Sun","Moon","Mars","Rahu","Jupiter","Saturn","Mercury"]

        years_map = {
            "Ketu":7,"Venus":20,"Sun":6,"Moon":10,
            "Mars":7,"Rahu":18,"Jupiter":16,
            "Saturn":19,"Mercury":17
        }

        size = 360 / 27

        # ---- Step 1: starting dasha ----
        nak_index = int(moon_lon // size)
        start_dasha = seq[nak_index % 9]

        # ---- Step 2: balance at birth ----
        balance = 1 - ((moon_lon % size) / size)
        remaining = years_map[start_dasha] * balance

        # ---- Step 3: years passed ----
        today = datetime.utcnow()
        years_passed = (today - birth_date).days / 365.25

        idx = seq.index(start_dasha)

        # ---- Step 4: find current Mahadasha ----
        if years_passed < remaining:
            current_maha = start_dasha
            maha_elapsed = years_passed
        else:
            years_passed -= remaining
            idx = (idx + 1) % 9

            while True:
                d = seq[idx]
                duration = years_map[d]

                if years_passed < duration:
                    current_maha = d
                    maha_elapsed = years_passed
                    break

                years_passed -= duration
                idx = (idx + 1) % 9

        # ---- Step 5: Antardasha inside current Mahadasha ----
        maha_duration = years_map[current_maha]

        for sub in seq:
            sub_duration = (maha_duration * years_map[sub]) / 120

            if maha_elapsed < sub_duration:
                return {
                    "mahadasha": current_maha,
                    "antardasha": f"{current_maha}/{sub}"
                }

            maha_elapsed -= sub_duration