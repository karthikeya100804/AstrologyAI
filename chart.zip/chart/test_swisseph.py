from chart.swisseph_wrapper import SwissEphChart

engine = SwissEphChart()

chart = engine.compute_chart(
    dob_str="06/02/1999",
    time_str="13:00",
    city="Nellore",
    state="Andhra Pradesh",
    country="India"
)

print(chart)